# create Toggle Password Visibility by using Pure JavaScript, HTML and CSS.
